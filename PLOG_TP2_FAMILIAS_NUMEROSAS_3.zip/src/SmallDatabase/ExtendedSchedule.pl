diaSemana(1,domingo).
diaSemana(2,segunda_feira).
diaSemana(3,terca_feira).
diaSemana(4,quarta_feira).
diaSemana(5,quinta_feira).
diaSemana(6,sexta_feira).
diaSemana(7,sabado).

%horarioActividade(_idActividade,_idDiaSemana,_HoraInicio)

